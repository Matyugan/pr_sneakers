<template lang="pug">
  section.section.section-hero-banner
    .container
      .hero-banner
        .hero-banner-content
          h2.hero-banner-content--title Register now and enter the draw of Nike SB Dunk “Safari”
          .hero-banner-content--time-action 1 d. 2 h. 39 m.
          nuxt-link.button.button_color.hero-banner-content--button(to="/raffles/NikeSBDunkLowPro\"Safari\"") Register
</template>

<script>
export default {
  name: 'c_HeroBanner'
}
</script>